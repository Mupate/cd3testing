#!/bin/bash

logfile="/tmp/installToolkit.log"
toolkit_dir="/tmp/githubCode"
username=cd3user

start=$(date +%s.%N)
stop_exec () {
if [[ $? -ne 0 ]] ; then
   echo $? >> $logfile
   echo "Error encountered in OCI Automation Toolkit Container Setup. Please do setup Manually" >> $logfile
   exit 1
fi
}

sudo systemctl stop oracle-cloud-agent.service
cd /etc/yum.repos.d/
for i in $( ls *.osms-backup ); do sudo mv $i ${i%.*}; done

echo "########################################################" >> $logfile
echo " Installing git on the server " >> $logfile
echo "########################################################" >> $logfile
sudo yum install -y git >> $logfile
stop_exec
echo "git installation completed successfully" >> $logfile
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo " Installing docker on the server " >> $logfile
echo "########################################################" >> $logfile
sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo >> $logfile
stop_exec
sudo yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >> $logfile
stop_exec
#sudo yum install -y docker-engine docker-cli >> $logfile
sudo systemctl enable docker.service >> $logfile
stop_exec
sudo systemctl start docker.service >> $logfile
stop_exec
sudo docker --version >> $logfile
stop_exec
echo "docker installation completed successfully" >> $logfile
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo "Downloading OCI Automation Toolkit Code from Github " >> $logfile
echo "########################################################" >> $logfile
sudo git clone https://github.com/Mupate/cd3testing.git $toolkit_dir >> $logfile
stop_exec
sudo ls -la /tmp/githubCode >> $logfile
echo "Downloading OCI Automation Toolkit Code from Github completed successfully" >> $logfile
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo "Building container image for OCI Automation Toolkit " >> $logfile
echo "########################################################" >> $logfile
cd /tmp
cd githubCode
echo "Building OCI Automation Toolkit Docker Image " >> $logfile
sudo docker build --platform linux/amd64 -t oci_toolkit -f Dockerfile --pull --no-cache . --progress=plain >> $logfile
stop_exec
sudo docker image ls >> $logfile
stop_exec
echo " " >> $logfile
echo " ********************************************** " >> $logfile

echo "########################################################" >> $logfile
echo "Setting Up cd3user for OCI Automation toolkit " >> $logfile
echo "########################################################" >> $logfile
sudo useradd -u 1001 -d /$username -m $username
sudo sh -c "echo cd3user ALL=\(root\) NOPASSWD:ALL > /etc/sudoers.d/cd3user"
sudo chmod 0440 /etc/sudoers.d/cd3user
sudo mkdir /cd3user/mount_path
stop_exec
sudo chmod 775 -R /cd3user
stop_exec
sudo chown -R cd3user:cd3user /cd3user
sudo usermod -aG cd3user opc
stop_exec
stop_exec
sudo id cd3user >> $logfile
echo " Successfully created cd3user with required permission " >> $logfile
echo " ********************************************** " >> $logfile

echo "########################################################" >> $logfile
echo "Setting Up OCI Automation Toolkit Docker Container " >> $logfile
echo "########################################################" >> $logfile
sudo docker run --name oci_toolkit -it -p 8443:8443 -d -v /cd3user/mount_path:/cd3user/tenancies  oci_toolkit bash >> $logfile
stop_exec
sudo docker ps -a >> $logfile
stop_exec
echo " " >> $logfile
echo "Successfully Created Docker Container named as oci_toolkit " >> $logfile
echo "Connect to Container using command - sudo docker exec -it oci_toolkit bash " >> $logfile
echo "########################################################" >> $logfile

sudo systemctl start oracle-cloud-agent.service

duration_sec=$(echo "$(date +%s.%N) - $start" | bc)
duration_min=$(echo "$duration_sec%3600/60" | bc)
execution_time=`printf "%.2f seconds" $duration_sec`
echo "Script Execution Time in Seconds: $execution_time" >> $logfile
echo "Script Execution Time in Minutes: approx $duration_min Minutes" >> $logfile
