#!/bin/bash

logfile="/tmp/installToolkit.log"
toolkit_dir="/tmp/githubCode"
username=cd3user

start=$(date +%s.%N)
stop_exec () {
if [[ $? -ne 0 ]] ; then
   echo $? >> $logfile
   echo "Error encountered in OCI Automation Toolkit Container Setup. Please do setup Manually" >> $logfile
   exit 1
fi
}
#echo "########################################################" > $logfile
#echo "Installing updates on the system" >> $logfile
#echo "########################################################" >> $logfile
#sudo yum update -y >> $logfile
#stop_exec
#echo "System updates completed successfully" >> $logfile
#sleep 2
sudo systemctl stop oracle-cloud-agent.service
cd /etc/yum.repos.d/
for i in $( ls *.osms-backup ); do mv $i ${i%.*}; done

echo "########################################################" >> $logfile
echo " Installing git on the server " >> $logfile
echo "########################################################" >> $logfile
sudo yum install -y git >> $logfile
stop_exec
echo "git installation completed successfully" >> $logfile

echo "########################################################" >> $logfile
echo " Installing docker on the server " >> $logfile
echo "########################################################" >> $logfile

sudo yum-config-manager --add-repo https://download.docker.com/linux/centos/docker-ce.repo >> $logfile
stop_exec
sudo yum install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin >> $logfile
stop_exec
#sudo yum install -y docker-engine docker-cli >> $logfile
sudo systemctl enable docker.service >> $logfile
stop_exec
sudo systemctl start docker.service >> $logfile
stop_exec
sudo docker --version >> $logfile
stop_exec
echo "docker installation completed successfully" >> $logfile

echo "########################################################" >> $logfile
echo "Downloading OCI Automation Toolkit Image from Github " >> $logfile
echo "########################################################" >> $logfile
sudo git clone https://github.com/Mupate/cd3testing.git $toolkit_dir >> $logfile
stop_exec
cd /tmp
cd githubCode
echo "Building OCI Automation Toolkit Docker Image " >> $logfile
sudo docker build --platform linux/amd64 -t oci_toolkit -f Dockerfile --pull --no-cache . --progress=plain >> $logfile
stop_exec
sudo docker image ls >> $logfile
stop_exec
echo "########################################################" >> $logfile
echo "Setting Up cd3user" >> $logfile
echo "########################################################" >> $logfile

sudo useradd -u 1001 -d /$username -m $username
#sudo usermod -aG wheel $username
sudo sh -c "echo $username ALL=\(root\) NOPASSWD:ALL > /etc/sudoers.d/$username"
sudo chmod 0440 /etc/sudoers.d/$username
stop_exec

echo "########################################################" >> $logfile
echo " Installing oci cli on the server " >> $logfile
echo "#######################################:q!#################" >> $logfile
#sudo yum install -y *-oci-cli* >> $logfile
sudo pip3
if [[ $? -ne 0 ]] ; then
   sudo yum install -y python3-pip
fi
sudo pip3 install oci-cli==3.37.0 >> $logfile
stop_exec
echo "oci cli installation completed successfully" >> $logfile

echo "########################################################" >> $logfile
echo "Setting Up OCI Automation Toolkit Docker Container " >> $logfile
echo "########################################################" >> $logfile

sudo docker image ls >> $logfile
stop_exec
echo " " >> $logfile
echo " ********************************************** " >> $logfile
sudo docker run --name oci_toolkit -it -p 8443:8443 -d -v /cd3user/:/cd3user/tenancies  oci_toolkit bash >> $logfile
stop_exec
sudo docker ps -a >> $logfile
stop_exec
echo " " >> $logfile
echo "Successfully Created Docker Container named as oci_toolkit " >> $logfile
echo "Connect to Container using command - sudo docker exec -it oci_toolkit bash " >> $logfile
echo "########################################################" >> $logfile

sudo systemctl start oracle-cloud-agent.service
duration_sec=$(echo "$(date +%s.%N) - $start" | bc)
duration_min=$(echo "$duration_sec%3600/60" | bc)
execution_time=`printf "%.2f seconds" $duration_sec`
echo "Script Execution Time in Seconds: $execution_time" >> $logfile
echo "Script Execution Time in Minutes: approx $duration_min Minutes" >> $logfile
