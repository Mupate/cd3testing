#!/bin/bash

logfile="/tmp/installToolkit.log"
toolkit_dir="/tmp/githubCode"
username=cd3user

start=$(date +%s.%N)
stop_exec () {
if [[ $? -ne 0 ]] ; then
   echo $? >> $logfile
   echo "Error encountered in OCI Automation Toolkit Container Setup. Please do setup Manually" >> $logfile
   exit 1
fi
}

sudo systemctl stop oracle-cloud-agent.service
cd /etc/yum.repos.d/
for i in $( ls *.osms-backup ); do sudo mv $i ${i%.*}; done

echo "########################################################" >> $logfile
echo " Setting SELinux to permissive " >> $logfile
echo "########################################################" >> $logfile
sudo setenforce 0
sudo sed -c -i "s/\SELINUX=.*/SELINUX=permissive/" /etc/sysconfig/selinux
sudo getenforce >> $logfile
stop_exec
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo " Installing git on the workvm " >> $logfile
echo "########################################################" >> $logfile
sudo yum install -y git >> $logfile
stop_exec
echo "git installation completed successfully" >> $logfile
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo " Installing Podman on the workvm " >> $logfile
echo "########################################################" >> $logfile
sudo yum install -y podman podman-docker >> $logfile
stop_exec
osrelase=`cat /etc/oracle-release`
if [[ $osrelase != "Oracle Linux Server release 7.9" ]] ; then
     sudo systemctl enable podman.service >> $logfile
     stop_exec
     sudo systemctl start podman.service  >> $logfile
     stop_exec
fi
sudo podman --version >> $logfile
stop_exec
echo "podman installation completed successfully" >> $logfile
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo "Downloading OCI Automation Toolkit Code from Github " >> $logfile
echo "########################################################" >> $logfile
sudo git clone https://github.com/Mupate/cd3testing.git $toolkit_dir >> $logfile
stop_exec
sudo ls -la /tmp/githubCode >> $logfile
echo "Downloading OCI Automation Toolkit Code from Github completed successfully" >> $logfile
echo "********************************************************" >> $logfile

echo "########################################################" >> $logfile
echo "Building container image for OCI Automation Toolkit " >> $logfile
echo "########################################################" >> $logfile
cd /tmp
cd githubCode
echo "Building OCI Automation Toolkit podman Image " >> $logfile
sudo podman build --platform linux/amd64 -t oci_toolkit -f Dockerfile --pull --no-cache . >> $logfile
#stop_exec
sudo podman images >> $logfile
stop_exec
echo " " >> $logfile
echo " ********************************************** " >> $logfile

echo "########################################################" >> $logfile
echo "Setting Up cd3user for OCI Automation toolkit " >> $logfile
echo "########################################################" >> $logfile
sudo useradd -u 1001 -d /$username -m $username
sudo sh -c "echo cd3user ALL=\(root\) NOPASSWD:ALL > /etc/sudoers.d/cd3user"
sudo chmod 0440 /etc/sudoers.d/cd3user
sudo mkdir -p /cd3user/mount_path
stop_exec
sudo chmod 775 -R /cd3user
stop_exec
sudo chown -R cd3user:cd3user /cd3user
sudo usermod -aG cd3user opc
stop_exec
sudo id cd3user >> $logfile
echo " Successfully created cd3user with required permission " >> $logfile
echo " ********************************************** " >> $logfile

echo "########################################################" >> $logfile
echo "Setting Up OCI Automation Toolkit podman Container " >> $logfile
echo "########################################################" >> $logfile
sudo podman run --name oci_toolkit -it -p 8443:8443 -d -v /cd3user/mount_path:/cd3user/tenancies  oci_toolkit bash >> $logfile
stop_exec
sudo podman ps -a >> $logfile
stop_exec
echo " " >> $logfile
echo "Successfully Created podman Container named as oci_toolkit " >> $logfile
echo "Connect to Container using command - sudo podman exec -it oci_toolkit bash " >> $logfile
echo "########################################################" >> $logfile

sudo systemctl start oracle-cloud-agent.service

duration_sec=$(echo "$(date +%s.%N) - $start" | bc)
duration_min=$(echo "$duration_sec%3600/60" | bc)
execution_time=`printf "%.2f seconds" $duration_sec`
echo "Script Execution Time in Seconds: $execution_time" >> $logfile
echo "Script Execution Time in Minutes: approx $duration_min Minutes" >> $logfile
